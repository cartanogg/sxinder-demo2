
import { useState } from 'react';

const usersNearby = [
  { name: "Laura", gender: "Mujer", lookingFor: "Hombres", city: "Bellinzona" },
  { name: "Marco", gender: "Hombre", lookingFor: "Mujeres", city: "Lugano" },
  { name: "Andrea", gender: "Otro", lookingFor: "Ambos", city: "Locarno" },
];

export default function SxinderApp() {
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState({ name: '', gender: '', lookingFor: '', language: 'es' });
  const [matches, setMatches] = useState([]);

  const t = (txt) => {
    const translations = {
      es: {
        welcome: "Bienvenido a Sxinder",
        name: "Tu nombre",
        gender: "Tu género",
        looking: "Buscás",
        start: "Empezar",
        select: "Seleccionar",
        nearby: "Personas cerca de Ticino",
        match: "¿Te interesa?",
        yes: "Sí",
        no: "No"
      },
      en: {
        welcome: "Welcome to Sxinder",
        name: "Your name",
        gender: "Your gender",
        looking: "Looking for",
        start: "Start",
        select: "Select",
        nearby: "People near Ticino",
        match: "Interested?",
        yes: "Yes",
        no: "No"
      },
      it: {
        welcome: "Benvenuto su Sxinder",
        name: "Il tuo nome",
        gender: "Il tuo genere",
        looking: "Cerchi",
        start: "Inizia",
        select: "Seleziona",
        nearby: "Persone vicino a Ticino",
        match: "Ti interessa?",
        yes: "Sì",
        no: "No"
      },
      de: {
        welcome: "Willkommen bei Sxinder",
        name: "Dein Name",
        gender: "Dein Geschlecht",
        looking: "Suche nach",
        start: "Start",
        select: "Auswählen",
        nearby: "Personen in der Nähe von Ticino",
        match: "Interessiert?",
        yes: "Ja",
        no: "Nein"
      }
    };
    return translations[profile.language][txt];
  };

  const handleMatch = (person) => {
    setMatches([...matches, person]);
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '600px', margin: 'auto', fontFamily: 'sans-serif' }}>
      {step === 0 && (
        <div style={{ border: '1px solid #ccc', borderRadius: '8px', padding: '1rem' }}>
          <h2>{t('welcome')}</h2>
          <input 
            placeholder={t('name')} 
            value={profile.name} 
            onChange={(e) => setProfile({ ...profile, name: e.target.value })} 
            style={{ display: 'block', marginBottom: '1rem', padding: '0.5rem', width: '100%' }}
          />

          <select 
            value={profile.gender} 
            onChange={(e) => setProfile({ ...profile, gender: e.target.value })}
            style={{ display: 'block', marginBottom: '1rem', padding: '0.5rem', width: '100%' }}
          >
            <option value="">{t('gender')}</option>
            <option value="Hombre">Hombre</option>
            <option value="Mujer">Mujer</option>
            <option value="Otro">Otro</option>
          </select>

          <select 
            value={profile.lookingFor} 
            onChange={(e) => setProfile({ ...profile, lookingFor: e.target.value })}
            style={{ display: 'block', marginBottom: '1rem', padding: '0.5rem', width: '100%' }}
          >
            <option value="">{t('looking')}</option>
            <option value="Hombres">Hombres</option>
            <option value="Mujeres">Mujeres</option>
            <option value="Ambos">Ambos</option>
          </select>

          <select 
            value={profile.language} 
            onChange={(e) => setProfile({ ...profile, language: e.target.value })}
            style={{ display: 'block', marginBottom: '1rem', padding: '0.5rem', width: '100%' }}
          >
            <option value="es">Español</option>
            <option value="en">English</option>
            <option value="it">Italiano</option>
            <option value="de">Deutsch</option>
          </select>

          <button onClick={() => setStep(1)} style={{ padding: '0.5rem 1rem' }}>{t('start')}</button>
        </div>
      )}

      {step === 1 && (
        <div style={{ marginTop: '2rem' }}>
          <h2>{t('nearby')}</h2>
          {usersNearby.map((user, idx) => (
            <div key={idx} style={{ border: '1px solid #ccc', borderRadius: '8px', padding: '1rem', marginBottom: '1rem' }}>
              <p><strong>{user.name}</strong> - {user.gender} ({user.city})</p>
              <p>{t('match')}</p>
              <div style={{ display: 'flex', gap: '1rem' }}>
                <button onClick={() => handleMatch(user)}>{t('yes')}</button>
                <button>{t('no')}</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
